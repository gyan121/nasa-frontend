import { ApodContainer, RoverContainer } from "./apod/container";

export interface AppState {
  apod: ApodContainer;
  rover: RoverContainer;
}
