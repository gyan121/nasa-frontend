import { createAsyncThunk } from "@reduxjs/toolkit";
import { RoverData } from "models/api/rover";
import { instance } from "utils/common";
import uniq from "lodash/uniq";

export const fetchRoverImages = createAsyncThunk(
  "fetchApod",
  async (_, { rejectWithValue }) => {
    try {
      const data = await instance.get("/rover");
      const photos = data.data.photos.map((item: RoverData) => item.img_src);

      return uniq(photos) as string[];
    } catch (e) {
      return rejectWithValue(e);
    }
  }
);
