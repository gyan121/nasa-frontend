import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch } from "store";
import { fetchApdo } from "store/actions";
import {
  StyledContainer,
  StyledDetails,
  StyledHeading,
  StyledImage,
} from "./styled";
import { selectApodData, selectRoverData } from "store/selectors";
import { Col, Flex, Row, Spin } from "antd";
import { fetchRoverImages } from "store/rover/action";

const Rover = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { images, isLoading } = useSelector(selectRoverData);

  useEffect(() => {
    dispatch(fetchRoverImages());
  }, []);

  if (isLoading) {
    return (
      <Flex
        align="center"
        justify="center"
        gap="middle"
        style={{ height: "100%" }}
      >
        <Spin size="large" />
      </Flex>
    );
  }

  return (
    <StyledContainer>
      <StyledHeading>Mars Rover Images</StyledHeading>
      <Row gutter={10}>
        {images.map((img) => (
          <Col sm={16} md={3} key={img} style={{ marginBottom: 10 }}>
            <StyledImage src={img} alt={img} />
          </Col>
        ))}
      </Row>
    </StyledContainer>
  );
};

export default Rover;
