export const theme = {
  token: {
    // Seed Token
    colorPrimary: "#3F4789",
    borderRadius: 2,

    // Alias Token
    colorBgContainer: "#f6ffed",
  },
};
