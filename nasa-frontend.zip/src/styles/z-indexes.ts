export const mainMenuZIndex = 9;
export const headerBarZIndex = 10;
export const pageHeaderZIndex = 8;

export const modalContainerZIndex = 12;
export const modalCoverZIndex = 11;

export const tableTitleZIndex = 11;
export const tableRowZIndex = 12;

export const sliderPanelZIndex = 1;
export const sliderButtonZIndex = 2;

export const workflowSubViewZIndex = 5;
export const expandPanelZIndex = 1;
export const automationSectionZIndex = 5;
export const automationZIndex = 2;
export const actionSectionZIndex = 2;

export const graphSectionZIndex = 2;
export const graphExpandedActionZIndex = 4;
export const graphStateZIndex = 3;
export const graphActionZIndex = 2;
export const graphEdgeZIndex = 1;
export const removeSectionZIndex = 1;
