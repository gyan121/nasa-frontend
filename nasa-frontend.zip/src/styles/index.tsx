export * from "./colors";
export * from "./font-styles";
export * from "./z-indexes";

export { default as GlobalStyles } from "./global-styles";
